@include('backend.layouts.navbar')
            <!-- /navbar-inner -->
       @include('backend.layouts.sidebar')
                    <!--/.span3-->
                         @include('backend.layouts.dashboard')
  
        <!--/.wrapper-->
               @include('backend.layouts.footer')

