<?php $__env->startSection('content'); ?>

<quiz-component
   :times ="<?php echo e($quiz->minutes); ?>"
   :quizId="<?php echo e($quiz->id); ?>"
   :quiz-questions = "<?php echo e($quizQuestions); ?>"
   :has-quiz-played ="<?php echo e($authUserHasPlayedQuiz); ?>"
   >


</quiz-component>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/quizapp/resources/views/quiz.blade.php ENDPATH**/ ?>