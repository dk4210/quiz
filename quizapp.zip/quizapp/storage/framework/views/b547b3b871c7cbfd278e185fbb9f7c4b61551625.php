<div class="footer">
            <div class="container">
                <b class="copyright">
            </div>
        </div>
        <script src="<?php echo e(asset('edmin/code/scripts/jquery-1.9.1.min.js" type="text/javascript')); ?>"></script>
        <script src="<?php echo e(asset('edmin/code/scripts/jquery-ui-1.10.1.custom.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('edmin/code/bootstrap/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('edmin/code/scripts/flot/jquery.flot.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('edmin/code/scripts/flot/jquery.flot.resize.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('edmin/code/scripts/datatables/jquery.dataTables.js')); ?>" type="text/javascript"></script>
        <script src="scripts/common.js" type="text/javascript"></script>
      
    </body><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/quizapp/resources/views/backend/layouts/footer.blade.php ENDPATH**/ ?>