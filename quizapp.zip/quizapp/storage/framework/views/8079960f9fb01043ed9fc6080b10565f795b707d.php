	<?php $__env->startSection('title','exam assigned user'); ?>

	<?php $__env->startSection('content'); ?>
<div class="span9">
                    <div class="content">
                    	
                        <div class="module">
                            <div class="module-head">
                                <h3>Result</h3>
                            </div>

                            <div class="module-body">
                            	<table class="table table-striped">
								  <thead>
									<tr>
									  <th>#</th>
									  <th>Test</th>
									  <th>Total Question</th>
									  <th>Attempt Question</th>
									  <th>Correct Answer</th>
									  <th>Wrong Answer</th>
									  <th>Percentage</th>
									</tr>
								  </thead>
								  <tbody>
								  	<?php $__currentLoopData = $quiz; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
									  <td>1</td>
									  <td><?php echo e($q->name); ?></td>
									  <td><?php echo e($totalQuestions); ?></td>
									  <td><?php echo e($attemptQuestion); ?></td>
									  <td><?php echo e($userCorrectedAnswer); ?></td>
									  <td><?php echo e($userWrongAnswer); ?></td>
									  <td><?php echo e(round($percentage,2)); ?></td>
									    
									  
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
								  </tbody>
								</table>


								<table class="table table-striped">
								  <thead>
									<tr>
									  <th>#</th>
									  <th>Question</th>
									  <th>Answer given</th>
									  <th>Result</th>
									  
									</tr>
								  </thead>
								  <tbody>
								  	<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
									  <td><?php echo e($key+1); ?></td>
									  <td><?php echo e($result->question->question); ?></td>
									  <td><?php echo e($result->answer->answer); ?></td>
									  <?php if($result->answer->is_correct): ?>
									  <td>Correct</td>

									  <?php else: ?>
									  <td>Wrong</td>
									  <?php endif; ?>
									  
									    
									  
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
								  </tbody>
								</table>

						 


                       		</div>
                   		</div>
                		
                		</div>
           			 
           			</div>
        		</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/quizapp/resources/views/backend/result/result.blade.php ENDPATH**/ ?>